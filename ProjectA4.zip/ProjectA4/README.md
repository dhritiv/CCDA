# CS167 Final Project A
<dl>
<dt>names:</dt> Dhriti Veeramachaneni, Abhinav Allam, Alex Nguyen, Kelly Wu
<dt>emails:</dt> dveer001@ucr.edu, aalla009@ucr.edu, nnguy414@ucr.edu, kwu116@ucr.edu
<dt>netID:</dt> dveer001, aalla009, nnguy414, kwu116
<dt>studentID:</dt> 862278381, 862200322, 862307399, 862318018
</dl>

## TASKS
### TASK 1 Data Preparation: Dhriti Veeramachaneni (dveer001)
### TASK 2 Spatial Analysis: Abhinav Allam (aalla009)
### TASK 3 Temporal Analysis: Alex Nguyen (nnguy414)
### TASK 4 Arrest Prediction: Kelly Wu (kwu116)
